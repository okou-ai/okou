Keep the source's typography.
